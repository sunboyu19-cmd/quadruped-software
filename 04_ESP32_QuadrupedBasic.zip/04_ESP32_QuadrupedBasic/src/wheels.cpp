#include <SimpleFOC.h>
#include <Wire.h>
#include <math.h>
#include "config.h"
#include "wheels.h"

static_assert(Config::VM>0 && Config::ALIGN_V>0 && Config::ALIGN_V<=Config::LIMIT_V &&
              Config::LIMIT_V<=Config::VM/2,"Check measured VM and voltage limits");

namespace {
portMUX_TYPE mux=portMUX_INITIALIZER_UNLOCKED;
WheelRequest desired;
WheelStatus published;
TwoWire bus1(1);
TwoWire* buses[2]={&Wire,&bus1};
MagneticSensorI2C sensor0(AS5600_I2C), sensor1(AS5600_I2C);
MagneticSensorI2C* sensors[2]={&sensor0,&sensor1};
BLDCDriver3PWM driver0(Config::PWM[0][0],Config::PWM[0][1],Config::PWM[0][2],Config::EN[0]);
BLDCDriver3PWM driver1(Config::PWM[1][0],Config::PWM[1][1],Config::PWM[1][2],Config::EN[1]);
BLDCDriver3PWM* drivers[2]={&driver0,&driver1};
BLDCMotor motor0(Config::POLE_PAIRS), motor1(Config::POLE_PAIRS);
BLDCMotor* motors[2]={&motor0,&motor1};
bool sensorOK[2]={false,false}, configured[2]={false,false};

WheelRequest getRequest() {
  portENTER_CRITICAL(&mux); WheelRequest r=desired; portEXIT_CRITICAL(&mux); return r;
}
void publish(const WheelStatus& s) {
  portENTER_CRITICAL(&mux); published=s; portEXIT_CRITICAL(&mux);
}
bool magnet(int i,uint8_t& status) {
  status=0;
  auto& b=*buses[i];
  b.beginTransmission(0x36); b.write(0x0b);
  if(b.endTransmission(false)!=0 || b.requestFrom(uint8_t(0x36),uint8_t(1))!=1) return false;
  status=b.read();
  return (status&0x20) && !(status&0x18);
}
void off() {
  for(int i=0;i<2;++i) {
    if(configured[i]) motors[i]->disable();
    digitalWrite(Config::EN[i],LOW);
  }
}
bool calibrate(int i,WheelStatus& s) {
  if(!magnet(i,s.mag[i])) { s.fault=101+i; return false; }
  if(!sensorOK[i]) { sensors[i]->init(buses[i]); sensorOK[i]=true; }
  if(!configured[i]) {
    auto& d=*drivers[i]; auto& m=*motors[i];
    d.voltage_power_supply=Config::VM; d.voltage_limit=Config::VM; d.pwm_frequency=25000;
    if(!d.init()) { s.fault=201+i; return false; }
    m.linkDriver(&d); m.linkSensor(sensors[i]);
    m.controller=MotionControlType::velocity;
    m.torque_controller=TorqueControlType::voltage;
    m.voltage_limit=Config::LIMIT_V; m.voltage_sensor_align=Config::ALIGN_V;
    m.velocity_limit=Config::MAX_SPEED;
    m.PID_velocity.P=0.2f; m.PID_velocity.I=1; m.PID_velocity.D=0;
    m.PID_velocity.output_ramp=10; m.LPF_velocity.Tf=0.02f;
    configured[i]=true;
    m.init(); m.disable();
    if(m.motor_status!=FOCMotorStatus::motor_uncalibrated) { s.fault=211+i; return false; }
  }
  auto& m=*motors[i];
  m.sensor_direction=Direction::UNKNOWN; m.zero_electric_angle=NOT_SET;
  m.enable(); const int ok=m.initFOC(); m.disable();
  if(!ok || !m.pp_check_result || !magnet(i,s.mag[i])) { s.fault=301+i; return false; }
  m.PID_velocity.reset(); return true;
}

void task(void*) {
  Wire.begin(Config::SDA[0],Config::SCL[0]);
  bus1.begin(Config::SDA[1],Config::SCL[1]);
  for(auto b:buses) { b->setClock(400000); b->setTimeOut(5); }
  WheelStatus s;
  uint32_t lastHealth=0,lastHz=millis(),lastTick=millis(),count=0;
  int bad[2]={0,0};
  for(;;) {
    auto r=getRequest(); uint32_t now=millis();
    if(r.mode!=Mode::Off && now-r.refreshed>Config::LINK_TIMEOUT_MS) {
      off(); s.state=State::Fault; s.fault=401;
    } else if(r.mode==Mode::Off) {
      if(s.state!=State::Off) off();
      s.state=State::Off; s.epoch=r.epoch; s.fault=0;
    } else if(r.mode==Mode::Calibrate && r.epoch!=s.epoch) {
      off(); s.epoch=r.epoch; s.fault=0; s.state=State::Calibrating; publish(s);
      bool success=true;
      for(int i=0;i<2;++i) {
        if(!calibrate(i,s)) { success=false; break; }
        const auto current=getRequest();
        if(current.mode!=Mode::Calibrate || current.epoch!=r.epoch ||
           millis()-current.refreshed>Config::LINK_TIMEOUT_MS) { success=false; s.fault=402; break; }
      }
      off(); s.state=success ? State::Ready : State::Fault;
      bad[0]=bad[1]=0; lastTick=millis(); publish(s);
    } else if(r.mode==Mode::Run && r.epoch==s.epoch &&
              (s.state==State::Ready || s.state==State::Running)) {
      if(s.state==State::Ready) {
        for(auto m:motors) { m->PID_velocity.reset(); m->enable(); }
        s.state=State::Running; lastTick=now;
      }
      if(now-lastTick>30) { off(); s.state=State::Fault; s.fault=403; }
      else {
        for(int i=0;i<2;++i) {
          const float v=r.target[i];
          if(!isfinite(v) || fabsf(v)>Config::MAX_SPEED) { s.fault=404; break; }
          motors[i]->loopFOC(); motors[i]->move(v);
          if(!isfinite(motors[i]->shaft_velocity) || fabsf(motors[i]->shaft_velocity)>Config::OVERSPEED) {
            s.fault=405+i; break;
          }
        }
        if(s.fault) { off(); s.state=State::Fault; }
      }
    } else if(r.mode==Mode::Run && s.state!=State::Fault) {
      off(); s.state=State::Fault; s.fault=407; // RUN without matching calibration.
    }
    lastTick=millis();
    if(now-lastHealth>=20) {
      lastHealth=now;
      for(int i=0;i<2;++i) {
        bool healthy=magnet(i,s.mag[i]);
        bad[i]=healthy ? 0 : bad[i]+1;
        if(healthy && !sensorOK[i]) { sensors[i]->init(buses[i]); sensorOK[i]=true; }
        if(s.state==State::Running && bad[i]>=3) { off(); s.state=State::Fault; s.fault=501+i; }
      }
    }
    // A previously initialised sensor may now be disconnected. Health probes
    // retry at 20ms; do not flood I2C/console with failed angle reads meanwhile.
    for(int i=0;i<2;++i) if(sensorOK[i] && bad[i]==0) {
      if(s.state!=State::Running) sensors[i]->update();
      s.angle[i]=sensors[i]->getAngle(); s.velocity[i]=sensors[i]->getVelocity();
    }
    ++count;
    if(now-lastHz>=1000) { s.hz=count*1000/(now-lastHz); count=0; lastHz=now; }
    publish(s); vTaskDelay(1);
  }
}
}
void requestWheels(const WheelRequest& r) {
  portENTER_CRITICAL(&mux); desired=r; portEXIT_CRITICAL(&mux);
}
WheelStatus wheelStatus() {
  portENTER_CRITICAL(&mux); auto s=published; portEXIT_CRITICAL(&mux); return s;
}
void startWheels() {
  for(int pin:Config::EN) { pinMode(pin,OUTPUT); digitalWrite(pin,LOW); }
  xTaskCreatePinnedToCore(task,"wheel_foc",8192,nullptr,3,nullptr,1);
}
