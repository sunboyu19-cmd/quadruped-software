#include <Preferences.h>
#include <math.h>
#include <string.h>
#include <algorithm>
#include "config.h"
#include "servos.h"

void ServoBank::loadTeaching() {
  Preferences p;
  if(!p.begin("servo-teach",true)) return;
  for(int i=0;i<4;++i) {
    char key[8]; snprintf(key,sizeof(key),"joint%d",Config::SERVO_IDS[i]);
    TeachingRecord r;
    if(p.getBytesLength(key)==sizeof(r) && p.getBytes(key,&r,sizeof(r))==sizeof(r) && validTeachingStorage(r)) teaching_[i]=r;
  }
  p.end();
}
bool ServoBank::storeTeaching(int i) {
  Preferences p;
  if(!p.begin("servo-teach",false)) return false;
  char key[8]; snprintf(key,sizeof(key),"joint%d",Config::SERVO_IDS[i]);
  sealTeaching(teaching_[i]);
  bool ok=p.putBytes(key,&teaching_[i],sizeof(teaching_[i]))==sizeof(teaching_[i]);
  p.end(); return ok;
}
bool ServoBank::refreshTeachingHardware(int i) {
  const int id=Config::SERVO_IDS[i];
  hardwareKnown_[i]=false;
  low[i]=bus.readWord(id,9); high[i]=bus.readWord(id,11);
  hardwareOffset_[i]=bus.readWord(id,31); hardwarePhase_[i]=bus.readByte(id,18);
  if(low[i]<0 || high[i]>4095 || low[i]>=high[i] || hardwareOffset_[i]<0 || hardwareOffset_[i]>8191 || hardwarePhase_[i]<0) return false;
  hardwareKnown_[i]=true; return true;
}
const char* ServoBank::teachingState(int i) const {
  const char* geometry=teachingGeometry(teaching_[i],lroundf(Config::SERVO_RANGE_DEG*4096/360)+8);
  if(strcmp(geometry,"VALID")) return geometry;
  if(!hardwareKnown_[i]) return "UNVERIFIED";
  if(teaching_[i].offset!=hardwareOffset_[i] || teaching_[i].phase!=hardwarePhase_[i]) return "STALE_ZERO";
  if(teaching_[i].stand<low[i] || teaching_[i].stand>high[i] || teaching_[i].lie<low[i] || teaching_[i].lie>high[i]) return "HW_LIMIT";
  return "VALID";
}
int ServoBank::teachingDirection(int i) const {
  if(strcmp(teachingState(i),"VALID")) return 0;
  return teaching_[i].stand>teaching_[i].lie ? 1 : -1;
}
bool ServoBank::taughtTargetAllowed(int i,int target) const {
  if(teaching_[i].mask!=3) return true; // Incomplete teaching retains the original small test window.
  if(strcmp(teachingState(i),"VALID")) return false;
  const int lo=std::min(teaching_[i].stand,teaching_[i].lie),hi=std::max(teaching_[i].stand,teaching_[i].lie);
  return target>=lo && target<=hi;
}
bool ServoBank::teachingLimits() {
  bool ok=true;
  for(int i=0;i<4;++i) {
    bool read=poll(i) && refreshTeachingHardware(i);
    if(!read) ok=false;
  }
  printTeaching(); return ok;
}
void ServoBank::printTeaching() {
  for(int i=0;i<4;++i) {
    const auto& t=teaching_[i];
    const int swlo=t.mask==3 ? std::min(t.stand,t.lie) : -1;
    const int swhi=t.mask==3 ? std::max(t.stand,t.lie) : -1;
    const int guard=lroundf(Config::SERVO_RANGE_DEG*4096/360)+8;
    const bool nearZero=status[i].valid && (status[i].position<guard || status[i].position>4095-guard);
    Serial.printf("TEACHDATA id=%d pos=%d feedback=%d hw_min=%d hw_max=%d hw_known=%d stand=%d lie=%d sw_min=%d sw_max=%d dir=%d state=%s offset=%d taught_offset=%u near_zero=%d age_ms=%ld\n",
      Config::SERVO_IDS[i],status[i].position,status[i].valid,low[i],high[i],hardwareKnown_[i],
      t.mask&1 ? t.stand:-1,t.mask&2 ? t.lie:-1,swlo,swhi,teachingDirection(i),teachingState(i),hardwareOffset_[i],t.offset,nearZero,
      status[i].sampled ? long(millis()-status[i].sampled):-1L);
  }
}
bool ServoBank::captureTeaching(bool standing,int selected) {
  if(active_ || setupActive_ || taughtMoving_ || selected< -1 || selected>3) {
    Serial.println("TEACH blocked: support body, RELAX and physically fix the desired pose first."); return false;
  }
  const int first=selected<0 ? 0:selected,last=selected<0 ? 3:selected;
  TeachingRecord candidates[4];
  int initial[4]={};
  for(int i=first;i<=last;++i) {
    if(!poll(i) || !refreshTeachingHardware(i) || bus.readByte(Config::SERVO_IDS[i],33)!=0 ||
       bus.readByte(Config::SERVO_IDS[i],40)!=0) {
      Serial.printf("TEACH blocked id=%d: require valid feedback, mode0 and actual torque OFF.\n",Config::SERVO_IDS[i]); return false;
    }
    if(status[i].position<low[i] || status[i].position>high[i]) {
      Serial.printf("TEACH blocked id=%d: physical position outside internal servo limits.\n",Config::SERVO_IDS[i]); return false;
    }
    initial[i]=status[i].position;
    candidates[i]=teaching_[i];
    if(candidates[i].mask && (candidates[i].offset!=hardwareOffset_[i] || candidates[i].phase!=hardwarePhase_[i])) candidates[i]=TeachingRecord{};
    candidates[i].offset=hardwareOffset_[i]; candidates[i].phase=hardwarePhase_[i];
  }
  for(int sample=0;sample<3;++sample) {
    delay(20);
    for(int i=first;i<=last;++i) {
      if(!poll(i)) return false;
      int delta=abs(status[i].position-initial[i]); delta=std::min(delta,4096-delta);
      if(delta>4) { Serial.printf("TEACH blocked id=%d: pose moved; hold still.\n",Config::SERVO_IDS[i]); return false; }
    }
  }
  for(int i=first;i<=last;++i) {
    if(standing) { candidates[i].stand=status[i].position; candidates[i].mask|=1; }
    else { candidates[i].lie=status[i].position; candidates[i].mask|=2; }
    teaching_[i]=candidates[i];
  }
  Serial.printf("TEACH captured %s in RAM; no motion or EEPROM writes. TEACHSAVE persists.\n",standing ? "STAND":"LIE");
  printTeaching(); return true;
}
bool ServoBank::saveTeaching() {
  bool ok=true;
  for(int i=0;i<4;++i) if(!storeTeaching(i)) ok=false;
  Serial.printf("TEACH saved_to_A_NVS=%d; servo EEPROM limits unchanged\n",ok);
  return ok;
}
bool ServoBank::clearTeaching(int selected) {
  if(selected< -1 || selected>3) return false;
  bool ok=true;
  for(int i=0;i<4;++i) if(selected<0 || selected==i) {
    teaching_[i]=TeachingRecord{};
    if(!storeTeaching(i)) ok=false;
  }
  return ok;
}
bool ServoBank::beginTaughtMove(float blend) {
  if(!active_ || fault_ || setupActive_ || !isfinite(blend) || blend<0 || blend>1) return false;
  int next[4];
  for(int i=0;i<4;++i) {
    if(!poll(i) || !refreshTeachingHardware(i) || strcmp(teachingState(i),"VALID")) {
      Serial.printf("POSTURE blocked id=%d state=%s: read limits/reteach or handle zero first.\n",Config::SERVO_IDS[i],teachingState(i)); return false;
    }
    const int lo=std::min(teaching_[i].stand,teaching_[i].lie),hi=std::max(teaching_[i].stand,teaching_[i].lie);
    if(status[i].position<lo-4 || status[i].position>hi+4) {
      Serial.printf("POSTURE blocked id=%d: current position outside taught interval.\n",Config::SERVO_IDS[i]); return false;
    }
    if(abs(status[i].position-goal[i])>64) {
      Serial.printf("POSTURE blocked id=%d: following error too large; support/check load before moving.\n",Config::SERVO_IDS[i]); return false;
    }
    next[i]=lroundf(teaching_[i].lie+blend*(teaching_[i].stand-teaching_[i].lie));
    if(!taughtTargetAllowed(i,next[i])) return false;
  }
  for(int i=0;i<4;++i) taughtGoal_[i]=next[i];
  taughtMoving_=true; taughtStart_=millis(); taughtTick_=0; taughtStable_=0;
  Serial.printf("POSTURE started stand_fraction=%.3f; slow taught-range motion, STOP holds last target\n",blend);
  return true;
}
void ServoBank::stopTaughtMove(const char* reason) {
  if(taughtMoving_) Serial.printf("POSTURE stopped: %s; last servo targets held\n",reason);
  taughtMoving_=false;
}
void ServoBank::tickTaughtMove() {
  if(!taughtMoving_ || millis()-taughtTick_<50) return;
  taughtTick_=millis();
  if(!active_ || fault_ || millis()-taughtStart_>45000) { stopTaughtMove("inactive/fault/45s timeout"); return; }
  bool settled=true;
  for(int i=0;i<4;++i) {
    if(!poll(i) || !taughtTargetAllowed(i,taughtGoal_[i])) { fault_=true; stopTaughtMove("feedback or range failure"); return; }
    const int lo=std::min(teaching_[i].stand,teaching_[i].lie),hi=std::max(teaching_[i].stand,teaching_[i].lie);
    if(status[i].position<lo-12 || status[i].position>hi+12) { fault_=true; stopTaughtMove("measured position outside taught interval"); return; }
    if(abs(status[i].position-goal[i])>64) { fault_=true; stopTaughtMove("servo cannot follow target; check load/torque"); return; }
    const int delta=taughtGoal_[i]-goal[i];
    const int next=goal[i]+std::max(-5,std::min(5,delta)); // <=100 counts/s at 50ms, ~8.8deg/s
    if(next!=goal[i] && (!taughtTargetAllowed(i,next) || !sendGoal(i,next))) { fault_=true; stopTaughtMove("write/range failure"); return; }
    if(goal[i]!=taughtGoal_[i] || abs(status[i].position-taughtGoal_[i])>8) settled=false;
  }
  taughtStable_=settled ? taughtStable_+1:0;
  if(taughtStable_>=3) {
    taughtMoving_=false; Serial.println("POSTURE reached; servo torque remains ON");
  }
}
